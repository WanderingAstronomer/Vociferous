# Architecture

This page documents the architectural design of Vociferous, including component boundaries, communication patterns, and threading model.

---

## Overview

Vociferous follows a **layered architecture** with clear separation between:

1. **Core Layer** — Application coordination, configuration, exceptions
2. **Services Layer** — Business logic (transcription, refinement, audio)
3. **Database Layer** — Persistence and data access
4. **UI Layer** — PyQt6 views, components, and styling

```
┌─────────────────────────────────────────────────────────────┐
│                         UI Layer                             │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐         │
│  │ Views   │  │Components│  │ Styles  │  │ Widgets │         │
│  └────┬────┘  └────┬────┘  └─────────┘  └─────────┘         │
│       │            │                                         │
│       └─────┬──────┘                                         │
│             │                                                │
│       ┌─────▼─────┐                                         │
│       │ MainWindow │                                         │
│       └─────┬─────┘                                         │
├─────────────┼───────────────────────────────────────────────┤
│             │           Core Layer                           │
│       ┌─────▼─────────────────┐                             │
│       │ ApplicationCoordinator │◄─── Composition Root        │
│       └─────┬─────────────────┘                             │
│             │                                                │
│    ┌────────┼────────┬─────────────┐                        │
│    │        │        │             │                        │
│ ┌──▼──┐ ┌──▼───┐ ┌──▼────┐  ┌────▼─────┐                   │
│ │State│ │Config│ │Resource│  │ Engine   │                   │
│ │Mgr  │ │Mgr   │ │Manager │  │ Client   │                   │
│ └─────┘ └──────┘ └────────┘  └────┬─────┘                   │
├────────────────────────────────────┼────────────────────────┤
│                                    │    Core Runtime         │
│                              ┌─────▼─────┐                   │
│                              │  Engine   │                   │
│                              │  Server   │                   │
│                              └─────┬─────┘                   │
│                                    │                         │
│                         ┌──────────┼──────────┐              │
│                         │          │          │              │
│                    ┌────▼───┐ ┌───▼────┐ ┌───▼────┐         │
│                    │Whisper │ │ Audio  │ │  SLM   │         │
│                    │ Engine │ │Capture │ │Service │         │
│                    └────────┘ └────────┘ └────────┘         │
├─────────────────────────────────────────────────────────────┤
│                      Database Layer                          │
│  ┌──────────────┐  ┌──────────┐  ┌─────────────┐           │
│  │HistoryManager│  │  Models  │  │Signal Bridge│           │
│  └──────────────┘  └──────────┘  └─────────────┘           │
└─────────────────────────────────────────────────────────────┘
```

---

## ApplicationCoordinator

The `ApplicationCoordinator` is the **composition root** — the single point where all major components are instantiated and wired together.

### Location

`src/core/application_coordinator.py`

### Responsibilities

| Responsibility | Description |
|----------------|-------------|
| Component Instantiation | Create all services, managers, and UI |
| Signal Wiring | Connect Qt signals between components |
| Lifecycle Management | Handle startup, shutdown, restart |
| State Propagation | Push engine state to UI |

### Key Methods

```python
class ApplicationCoordinator:
    def __init__(self):
        # Create components
        self.config_manager = ConfigManager.instance()
        self.state_manager = StateManager()
        self.history_manager = HistoryManager()
        self.engine_client = EngineClient()
        self.slm_service = SLMService()
        self.main_window = MainWindow()
        
        # Wire signals
        self._connect_signals()
    
    def start(self):
        """Start all background threads and show UI."""
        self.engine_client.start()
        self.slm_thread.start()
        self.main_window.show()
    
    def shutdown(self):
        """Clean shutdown of all components."""
        self.slm_service.cleanup()
        self.engine_client.stop()
        self.history_manager.close()
```

### Invariant

> **The orchestrator is the ONLY entity allowed to push background engine state (Recording, Transcribing, Idle) into the UI layer.**

*Derived from implementation: Direct UI mutation from background components is forbidden.*

---

## Engine Client/Server Pattern

Vociferous uses an **IPC pattern** to separate the UI process from compute-intensive operations.

### Components

| Component | Location | Purpose |
|-----------|----------|---------|
| EngineClient | `src/core_runtime/client.py` | UI-side proxy |
| EngineServer | `src/core_runtime/server.py` | Worker process |
| TranscriptionEngine | `src/core_runtime/engine.py` | Whisper wrapper |

### Communication Flow

```mermaid
sequenceDiagram
    participant UI as MainWindow
    participant AC as Coordinator
    participant EC as EngineClient
    participant ES as EngineServer
    participant TE as TranscriptionEngine

    UI->>AC: BeginRecordingIntent
    AC->>EC: start_recording()
    EC->>ES: IPC: START_RECORDING
    ES->>ES: Begin audio capture
    
    UI->>AC: StopRecordingIntent
    AC->>EC: stop_recording()
    EC->>ES: IPC: STOP_RECORDING
    ES->>TE: transcribe(audio)
    TE-->>ES: TranscriptionResult
    ES-->>EC: IPC: RESULT
    EC-->>AC: transcription_complete(result)
    AC-->>UI: display_transcript(result)
```

### State Machine

```mermaid
stateDiagram-v2
    [*] --> IDLE
    IDLE --> RECORDING: start_recording()
    RECORDING --> TRANSCRIBING: stop_recording()
    TRANSCRIBING --> IDLE: result_ready
    RECORDING --> IDLE: cancel_recording()
    TRANSCRIBING --> IDLE: error
```

---

## Service Layer

Services encapsulate business logic and run on background threads.

### SLMService

**Location:** `src/services/slm_service.py`

**Purpose:** Manage refinement model lifecycle and execution

**Thread:** Dedicated QThread via `moveToThread()`

**Key Signals:**
- `stateChanged(SLMState)` — State machine transition
- `refinementSuccess(int, str)` — Refinement complete
- `refinementError(int, str)` — Refinement failed

### WhisperTranscriptionEngine

**Location:** `src/core_runtime/engine.py`

**Purpose:** Wrap faster-whisper for transcription

**Thread:** Runs in EngineServer process

---

## UI Layer

### MainWindow

**Location:** `src/ui/main_window.py`

**Role:** Application shell containing navigation and view host

**Layout:**
```
┌────────────────────────────────────────────────┐
│                  MainWindow                     │
│  ┌──────┬──────────────────────────┬────────┐  │
│  │      │                          │        │  │
│  │ Icon │       ViewHost           │ Action │  │
│  │ Rail │                          │  Dock  │  │
│  │      │                          │        │  │
│  └──────┴──────────────────────────┴────────┘  │
└────────────────────────────────────────────────┘
```

### View Architecture

All views extend `BaseView` and implement:

```python
class ViewInterface(Protocol):
    def get_view_id(self) -> str: ...
    def get_capabilities(self) -> Capabilities: ...
    def dispatch_action(self, action_id: ActionId) -> None: ...
    def get_selection(self) -> SelectionState: ...
```

### Navigation

```mermaid
flowchart LR
    IR[IconRail] -->|click| VH[ViewHost]
    VH -->|show| TV[TranscribeView]
    VH -->|show| HV[HistoryView]
    VH -->|show| SV[SearchView]
    VH -->|show| RV[RefineView]
    VH -->|show| SetV[SettingsView]
    VH -->|show| UV[UserView]
```

---

## Threading Model

### Thread Inventory

| Thread | Owner | Purpose |
|--------|-------|---------|
| Main Thread | QApplication | UI event loop |
| Engine Server | Subprocess | Audio capture, transcription |
| SLM Thread | QThread | Refinement inference |
| Provisioning | QThreadPool | Model downloads |

### Thread Safety Rules

1. **Never block the Qt main thread**
2. **Never share mutable state across threads**
3. **All cross-thread communication via `pyqtSignal`**

### Signal-Based Communication

```mermaid
sequenceDiagram
    participant BG as Background Thread
    participant SIG as Qt Signal
    participant MT as Main Thread
    participant UI as UI Component

    BG->>SIG: emit(data)
    SIG->>MT: Queued Connection
    MT->>UI: Update widget
```

---

## Configuration

### ConfigManager

**Location:** `src/core/config_manager.py`

**Pattern:** Singleton with schema validation

**Schema:** `src/config_schema.yaml`

### Access Pattern

```python
# Read
value = ConfigManager.get_config_value("section", "key")

# Write
ConfigManager.set_config_value("section", "key", new_value)

# Listen for changes
config_manager.config_changed.connect(handler)
```

---

## Resource Management

### ResourceManager

**Location:** `src/core/resource_manager.py`

**Purpose:** Centralized asset path resolution

**Assets:** Icons, stylesheets, model paths

```python
icon_path = ResourceManager.get_icon_path("record")
```

---

## Error Handling

### Exception Hierarchy

```
VociferousError (Base)
├── ConfigurationError
├── TranscriptionError
├── RefinementError
├── DatabaseError
└── InputError
```

**Location:** `src/core/exceptions.py`

---

## Key Architectural Decisions

### 1. Composition over Inheritance

Components are composed at runtime by the Coordinator rather than through deep inheritance hierarchies.

### 2. Intent-Driven UI

User actions emit **intents** (immutable dataclasses) that propagate upward through the widget hierarchy for centralized handling.

### 3. Dual-Text Invariant

Transcripts maintain separate `raw_text` (immutable Whisper output) and `normalized_text` (editable user content).

### 4. View Capabilities

Each view advertises its current capabilities, and the ActionDock dynamically shows/hides buttons.

---

## See Also

- [Design System](Design-System) — UI tokens and styling
- [Data and Persistence](Data-and-Persistence) — Database layer
- [UI Views Overview](UI-Views-Overview) — View architecture details
